package com.example.juniorloor.SECRETARIA;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity{

    private EditText Codigo;
    private Button consultar;
    private TextView RCodigo, RPersona, RFecha, RHora;
    HelperDB helperDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Codigo = findViewById(R.id.TXTCodigo);
        consultar = findViewById(R.id.BTNConsultar);
        RCodigo = findViewById(R.id.LBLCodigo);
        RPersona = findViewById(R.id.LBLPersona);
        RFecha = findViewById(R.id.LBLFecha);
        RHora = findViewById(R.id.LBLHora);
        helperDB = new HelperDB(this, "bda", null, 1);
        consultar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Codigo.getText().toString().isEmpty()){

                }else {
                    Buscar(v);
                }
            }
        });

    }

    public void Buscar(View view){
        String codigo = Codigo.getText().toString();
        Cursor cursor = helperDB.getReadableDatabase().rawQuery("SELECT * FROM ESTACIONAMIENTO WHERE codigo="+ codigo, null);
        if(cursor.moveToFirst()){
                    String codigoPersona = cursor.getString(0);
                    String personaPersona = cursor.getString(1);
                    String fechaPersona = cursor.getString(2);
                    String horaPersona = cursor.getString(3);
                    RCodigo.setText(getString(R.string.placa) + " " + codigoPersona);
                    RPersona.setText(getString(R.string.persona) + "" + personaPersona);
                    RFecha.setText(getString(R.string.fecha) + " " + fechaPersona);
                    RHora.setText(getString(R.string.hora) + " " + horaPersona);
                    Codigo.setText("");

            }else {
                Toast.makeText(MainActivity.this, getString(R.string.Toast), Toast.LENGTH_LONG).show();
                startActivity(new Intent(MainActivity.this, Main2Activity.class));
                finish();
            }
        }
    }

