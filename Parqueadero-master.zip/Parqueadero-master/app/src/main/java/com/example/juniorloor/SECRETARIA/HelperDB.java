package com.example.juniorloor.SECRETARIA;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
public class HelperDB extends SQLiteOpenHelper {
    public HelperDB(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE ESTACIONAMIENTO(codigo INTEGER PRIMARY KEY, persona TEXT, " +
                "fecha TEXT, hora TEXT);" );
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void insertar (String codigo, String persona, String fecha, String hora){
        ContentValues values = new ContentValues();
        values.put("codigo", codigo);
        values.put("persona", persona);
        values.put("fecha", fecha);
        values.put("hora", hora);
        this.getWritableDatabase().insert("ESTACIONAMIENTO", null, values);
    }

}