package com.example.juniorloor.SECRETARIA;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Main2Activity extends AppCompatActivity {

    private EditText codigoN, persona, fecha, hora;
    private Button guardar;
    private HelperDB helperDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        codigoN = findViewById(R.id.TXTCodigoN);
        persona = findViewById(R.id.TXTPersona);
        fecha = findViewById(R.id.TXTFecha);
        hora = findViewById(R.id.TXTHora);
        guardar = findViewById(R.id.BTNGuardar);
        helperDB = new HelperDB(this, "bda", null, 1);

        guardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (codigoN.getText().toString().isEmpty()){
                    codigoN.setError(getString(R.string.VALIDAR));
                }else if (persona.getText().toString().isEmpty()){
                    persona.setError(getString(R.string.VALIDAR));
                }else if (fecha.getText().toString().isEmpty()){
                    fecha.setError(getString(R.string.VALIDAR));
                }else if (hora.getText().toString().isEmpty()){
                    hora.setError(getString(R.string.VALIDAR));
                }else  {
                    helperDB.insertar(codigoN.getText().toString(), persona.getText().toString(), fecha.getText().toString(), hora.getText().toString());
                    startActivity(new Intent(Main2Activity.this, MainActivity.class));
                    finish();
                }

            }
        });
    }
}
